package com.filmes.crud.model;

public class Film {

    private int ID;
    private String title;
    private String description;
    private int releaseDate;
    private String[] directors;
    private float rating;
    private int totalReviews;

    public Film() {
    }

    public Film(String title, String description, int releaseDate, String[] directors) {
        this.title = title;
        this.description = description;
        this.releaseDate = releaseDate;
        this.directors = directors;
        this.rating = 0;
        this.totalReviews = 0;
    }

    public Film(int ID, String title, String description, int releaseDate, String[] directors, float rating, int totalReviews) {
        this.ID = ID;
        this.title = title;
        this.description = description;
        this.releaseDate = releaseDate;
        this.directors = directors;
        this.rating = rating;
        this.totalReviews = totalReviews;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Alias HTML
    public String getTitulo() {
        return title;
    }

    public void setTitulo(String titulo) {
        this.title = titulo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Alias HTML
    public String getDescricao() {
        return description;
    }

    public void setDescricao(String descricao) {
        this.description = descricao;
    }

    public int getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(int releaseDate) {
        this.releaseDate = releaseDate;
    }

    // Alias HTML → formato yyyy-mm-dd
    public String getDataLancamento() {
        if (releaseDate <= 0) return "";

        String data = String.valueOf(releaseDate);
        if (data.length() != 8) return data;

        return data.substring(0, 4) + "-" +
               data.substring(4, 6) + "-" +
               data.substring(6, 8);
    }

    public void setDataLancamento(String dataLancamento) {
        if (dataLancamento == null || dataLancamento.trim().isEmpty()) {
            this.releaseDate = 0;
            return;
        }

        try {
            String limpa = dataLancamento.replace("-", "").trim();
            this.releaseDate = Integer.parseInt(limpa);
        } catch (Exception e) {
            this.releaseDate = 0;
        }
    }

    public String[] getDirectors() {
        return directors;
    }

    public void setDirectors(String[] directors) {
        this.directors = directors;
    }

    // Alias HTML → string única
    public String getDiretores() {
        if (directors == null || directors.length == 0) {
            return "";
        }
        return String.join(", ", directors);
    }

    public void setDiretores(String diretoresTexto) {
        if (diretoresTexto == null || diretoresTexto.trim().isEmpty()) {
            this.directors = new String[0];
            return;
        }

        String[] partes = diretoresTexto.split(",");
        for (int i = 0; i < partes.length; i++) {
            partes[i] = partes[i].trim();
        }

        this.directors = partes;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getTotalReviews() {
        return totalReviews;
    }

    public void setTotalReviews(int totalReviews) {
        this.totalReviews = totalReviews;
    }
}