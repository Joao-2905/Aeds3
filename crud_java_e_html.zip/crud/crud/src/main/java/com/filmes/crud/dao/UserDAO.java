package com.filmes.crud.dao;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

import com.filmes.crud.index.Bucket;
import com.filmes.crud.index.HashExtensivel;
import com.filmes.crud.index.IndexEntry;
import com.filmes.crud.model.User;
import com.filmes.crud.util.Crypto;
import com.filmes.crud.util.FileManeger;

public class UserDAO {

    private final String FILE = "data/user.bin";
    private HashExtensivel indice;

    public UserDAO() throws IOException {
        initFile();
        indice = new HashExtensivel(2);
        reconstruirIndice();
    }

    private void initFile() throws IOException {
        System.out.println("INIT USER DAO");

        RandomAccessFile raf = FileManeger.open(FILE);

        if (raf.length() == 0) {
            raf.writeInt(0); // último ID
            raf.close();

            User admin = new User(
                "admin",
                "admin@admin.com",
                "123",
                true
            );

            create(admin);

            System.out.println("Administrador padrão criado:");
            System.out.println("Email: admin@admin.com");
            System.out.println("Senha: 123");
        } else {
            raf.close();
        }
    }

    private void reconstruirIndice() throws IOException {
        indice = new HashExtensivel(2);

        RandomAccessFile raf = FileManeger.open(FILE);
        raf.seek(4); // pula cabeçalho

        while (raf.getFilePointer() < raf.length()) {
            long pos = raf.getFilePointer();

            int recordSize = raf.readInt();
            boolean active = raf.readBoolean();
            int id = raf.readInt();

            if (active) {
                indice.inserir(id, pos);
            }

            raf.seek(pos + 4L + recordSize);
        }

        raf.close();
    }

    // CREATE
    public int create(User user) throws IOException {
        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(0);
        int lastID = raf.readInt();
        int newID = lastID + 1;

        raf.seek(0);
        raf.writeInt(newID);

        byte[] usernameBytes = user.getUsername().getBytes(StandardCharsets.UTF_8);
        short usernameSize = (short) usernameBytes.length;

        byte[] emailBytes = user.getEmail().getBytes(StandardCharsets.UTF_8);
        short emailSize = (short) emailBytes.length;

        String encryptedPassword = Crypto.xor(user.getPassword());
        byte[] passwordBytes = encryptedPassword.getBytes(StandardCharsets.UTF_8);
        short passwordSize = (short) passwordBytes.length;

        int recordSize =
                1 +                 // active
                4 +                 // id
                2 + usernameSize +  // username
                2 + emailSize +     // email
                2 + passwordSize +  // password
                1;                  // administrador

        long pos = raf.length();
        raf.seek(pos);

        raf.writeInt(recordSize);
        raf.writeBoolean(true);
        raf.writeInt(newID);

        raf.writeShort(usernameSize);
        raf.write(usernameBytes);

        raf.writeShort(emailSize);
        raf.write(emailBytes);

        raf.writeShort(passwordSize);
        raf.write(passwordBytes);

        raf.writeBoolean(user.isAdministrator());

        raf.close();

        indice.inserir(newID, pos);

        return newID;
    }

    // READ por ID
    public User read(int idBusca) throws IOException {
        Long pos = indice.buscar(idBusca);
        if (pos == null) {
            return null;
        }

        RandomAccessFile raf = FileManeger.open(FILE);
        User user = readAtPosition(raf, pos, idBusca);
        raf.close();

        return user;
    }

    private User readAtPosition(RandomAccessFile raf, long pos, int expectedId) throws IOException {
        raf.seek(pos);

        raf.readInt(); // recordSize
        boolean active = raf.readBoolean();
        int id = raf.readInt();

        if (!active || id != expectedId) {
            return null;
        }

        short usernameSize = raf.readShort();
        byte[] usernameBytes = new byte[usernameSize];
        raf.readFully(usernameBytes);
        String username = new String(usernameBytes, StandardCharsets.UTF_8);

        short emailSize = raf.readShort();
        byte[] emailBytes = new byte[emailSize];
        raf.readFully(emailBytes);
        String email = new String(emailBytes, StandardCharsets.UTF_8);

        short passwordSize = raf.readShort();
        byte[] passwordBytes = new byte[passwordSize];
        raf.readFully(passwordBytes);
        String encryptedPassword = new String(passwordBytes, StandardCharsets.UTF_8);
        String password = Crypto.xor(encryptedPassword);

        boolean administrador = raf.readBoolean();

        return new User(id, username, email, password, administrador);
    }

    // READ por email
    public User readByEmail(String emailBusca) throws IOException {
        RandomAccessFile raf = FileManeger.open(FILE);
        raf.seek(4);

        while (raf.getFilePointer() < raf.length()) {
            long pos = raf.getFilePointer();

            int recordSize = raf.readInt();
            boolean active = raf.readBoolean();

            if (!active) {
                raf.seek(pos + 4L + recordSize);
                continue;
            }

            int id = raf.readInt();

            short usernameSize = raf.readShort();
            byte[] usernameBytes = new byte[usernameSize];
            raf.readFully(usernameBytes);
            String username = new String(usernameBytes, StandardCharsets.UTF_8);

            short emailSize = raf.readShort();
            byte[] emailBytes = new byte[emailSize];
            raf.readFully(emailBytes);
            String email = new String(emailBytes, StandardCharsets.UTF_8);

            short passwordSize = raf.readShort();
            byte[] passwordBytes = new byte[passwordSize];
            raf.readFully(passwordBytes);
            String encryptedPassword = new String(passwordBytes, StandardCharsets.UTF_8);
            String password = Crypto.xor(encryptedPassword);

            boolean administrador = raf.readBoolean();

            if (email.equals(emailBusca)) {
                raf.close();
                return new User(id, username, email, password, administrador);
            }

            raf.seek(pos + 4L + recordSize);
        }

        raf.close();
        return null;
    }

    // UPDATE
    public boolean update(User user) throws IOException {
        Long pos = indice.buscar(user.getID());
        if (pos == null) {
            return false;
        }

        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(pos + 4); // pula tamanho do registro
        boolean active = raf.readBoolean();

        if (!active) {
            raf.close();
            return false;
        }

        raf.seek(pos + 4);
        raf.writeBoolean(false); // marca como inativo
        raf.close();

        long novaPos = createWithIdRetornandoPosicao(user);
        indice.inserir(user.getID(), novaPos);

        return true;
    }

    private long createWithIdRetornandoPosicao(User user) throws IOException {
        RandomAccessFile raf = FileManeger.open(FILE);

        byte[] usernameBytes = user.getUsername().getBytes(StandardCharsets.UTF_8);
        short usernameSize = (short) usernameBytes.length;

        byte[] emailBytes = user.getEmail().getBytes(StandardCharsets.UTF_8);
        short emailSize = (short) emailBytes.length;

        String encryptedPassword = Crypto.xor(user.getPassword());
        byte[] passwordBytes = encryptedPassword.getBytes(StandardCharsets.UTF_8);
        short passwordSize = (short) passwordBytes.length;

        int recordSize =
                1 +
                4 +
                2 + usernameSize +
                2 + emailSize +
                2 + passwordSize +
                1;

        long pos = raf.length();
        raf.seek(pos);

        raf.writeInt(recordSize);
        raf.writeBoolean(true);
        raf.writeInt(user.getID());

        raf.writeShort(usernameSize);
        raf.write(usernameBytes);

        raf.writeShort(emailSize);
        raf.write(emailBytes);

        raf.writeShort(passwordSize);
        raf.write(passwordBytes);

        raf.writeBoolean(user.isAdministrator());

        raf.close();
        return pos;
    }

    // DELETE
    public boolean delete(int id) throws IOException {
        Long pos = indice.buscar(id);
        if (pos == null) {
            return false;
        }

        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(pos + 4);
        boolean active = raf.readBoolean();

        if (!active) {
            raf.close();
            return false;
        }

        raf.seek(pos + 4);
        raf.writeBoolean(false);

        raf.close();

        indice.remover(id);
        return true;
    }

    // LISTAR TODOS
    public void listAll() throws IOException {
        RandomAccessFile raf = FileManeger.open(FILE);
        raf.seek(4);

        System.out.println("\n--- Users ---");

        while (raf.getFilePointer() < raf.length()) {
            long pos = raf.getFilePointer();

            int recordSize = raf.readInt();
            boolean active = raf.readBoolean();

            if (!active) {
                raf.seek(pos + 4L + recordSize);
                continue;
            }

            int id = raf.readInt();

            short usernameSize = raf.readShort();
            byte[] usernameBytes = new byte[usernameSize];
            raf.readFully(usernameBytes);
            String username = new String(usernameBytes, StandardCharsets.UTF_8);

            short emailSize = raf.readShort();
            byte[] emailBytes = new byte[emailSize];
            raf.readFully(emailBytes);
            String email = new String(emailBytes, StandardCharsets.UTF_8);

            short passwordSize = raf.readShort();
            byte[] passwordBytes = new byte[passwordSize];
            raf.readFully(passwordBytes);
            String encryptedPassword = new String(passwordBytes, StandardCharsets.UTF_8);
            String password = Crypto.xor(encryptedPassword);

            boolean administrador = raf.readBoolean();

            System.out.println(
                id + " | " + username + " | " + email + " | " + password + " | admin: " + administrador
            );

            raf.seek(pos + 4L + recordSize);
        }

        raf.close();
    }

    public void exibirIndice() {
        indice.exibir("usuario");
    }

    // VALIDAÇÃO DO ÍNDICE
    public void validarIndice() throws IOException {
        System.out.println("\n=== VALIDANDO HASH EXTENSÍVEL (USER) ===");

        RandomAccessFile raf = FileManeger.open(FILE);

        for (int i = 0; i < indice.getDiretorio().size(); i++) {
            Bucket bucket = indice.getDiretorio().get(i);

            for (IndexEntry entry : bucket.getEntradas()) {
                int id = entry.getId();
                long pos = entry.getEndereco();

                if (pos < 4 || pos >= raf.length()) {
                    System.out.println("❌ ERRO!");
                    System.out.println("ID no índice: " + id);
                    System.out.println("Offset inválido: " + pos);
                    continue;
                }

                raf.seek(pos);

                int size = raf.readInt();
                boolean active = raf.readBoolean();
                int idLido = raf.readInt();

                if (!active) {
                    System.out.println("⚠️ Registro deletado ainda presente no índice! ID: " + id);
                    continue;
                }

                if (id != idLido) {
                    System.out.println("❌ ERRO!");
                    System.out.println("ID no índice: " + id);
                    System.out.println("ID no arquivo: " + idLido);
                    System.out.println("Posição: " + pos);
                    System.out.println("Tamanho do registro: " + size);
                } else {
                    System.out.println("✔ OK -> ID: " + id + " | Offset: " + pos);
                }
            }
        }

        raf.close();
    }
}