package com.filmes.crud.service;

import java.util.List;

import com.filmes.crud.dao.FilmDAO;
import com.filmes.crud.model.Film;

public class FilmService {

    private final FilmDAO filmDao;

    public FilmService() throws Exception {
        filmDao = new FilmDAO();
    }

    public int createFilm(String title, String description, int releaseDate, String[] directors, float rating) throws Exception {

        validarTitulo(title);
        validarDescricao(description);
        validarData(releaseDate);
        validarDiretores(directors);
        validarNota(rating);

        Film film = new Film(title, description, releaseDate, directors);
        film.setRating(rating);
        film.setTotalReviews(1);

        return filmDao.create(film);
    }

    public Film readFilm(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID inválido.");
        }

        return filmDao.read(id);
    }

    public List<Film> listFilmsToList() throws Exception {
        return filmDao.readAllToList();
    }

    public boolean deleteFilm(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID inválido.");
        }

        return filmDao.delete(id);
    }

    public boolean updateFilm(Film film) throws Exception {
        if (film == null) {
            throw new Exception("Filme inválido.");
        }

        if (film.getID() <= 0) {
            throw new Exception("ID inválido.");
        }

        validarTitulo(film.getTitle());
        validarDescricao(film.getDescription());
        validarData(film.getReleaseDate());
        validarDiretores(film.getDirectors());
        validarNota(film.getRating());

        return filmDao.update(film);
    }

    public void listFilms() throws Exception {
        filmDao.listAll();
    }

    public void exibirIndice() throws Exception {
        filmDao.exibirIndice();
    }

    private void validarTitulo(String title) throws Exception {
        if (title == null || title.trim().isEmpty()) {
            throw new Exception("Título não pode ser vazio.");
        }
    }

    private void validarDescricao(String description) throws Exception {
        if (description == null || description.trim().isEmpty()) {
            throw new Exception("Descrição não pode ser vazia.");
        }
    }

    private void validarData(int releaseDate) throws Exception {
        if (String.valueOf(releaseDate).length() != 8) {
            throw new Exception("A data deve estar no formato AAAAMMDD.");
        }

        if (!dataValida(releaseDate)) {
            throw new Exception("Data inválida.");
        }
    }

    private void validarDiretores(String[] directors) throws Exception {
        if (directors == null || directors.length == 0) {
            throw new Exception("O filme precisa ter pelo menos um diretor.");
        }

        for (String diretor : directors) {
            if (diretor == null || diretor.trim().isEmpty()) {
                throw new Exception("Nome de diretor inválido.");
            }
        }
    }

    private void validarNota(float rating) throws Exception {
        if (rating < 0 || rating > 10) {
            throw new Exception("A nota deve estar entre 0 e 10.");
        }
    }

    private boolean dataValida(int data) {
        int ano = data / 10000;
        int mes = (data / 100) % 100;
        int dia = data % 100;

        if (ano < 1800 || ano > 3000) {
            return false;
        }

        if (mes < 1 || mes > 12) {
            return false;
        }

        int[] diasMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
            diasMes[1] = 29;
        }

        return dia >= 1 && dia <= diasMes[mes - 1];
    }
}