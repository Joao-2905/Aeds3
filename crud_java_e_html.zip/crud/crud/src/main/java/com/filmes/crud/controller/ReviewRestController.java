package com.filmes.crud.controller;

import com.filmes.crud.dao.ReviewDAO;
import com.filmes.crud.model.Review;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewRestController {

    private final ReviewDAO dao;

    public ReviewRestController() throws Exception {
        this.dao = new ReviewDAO();
    }

    // 🔹 LISTAR TODAS
    @GetMapping
    public List<Review> listar() throws Exception {
        return dao.readAllToList();
    }

    // 🔹 BUSCAR POR ID
    @GetMapping("/{id}")
    public Review buscar(@PathVariable int id) throws Exception {
        return dao.read(id);
    }

    // 🔹 CRIAR
    @PostMapping
    public String criar(@RequestBody Review review) {
        try {
            int id = dao.create(review);
            return "Review criada com ID: " + id;
        } catch (Exception e) {
            return "Erro ao criar review: " + e.getMessage();
        }
    }

    // 🔹 ATUALIZAR
    @PutMapping("/{id}")
    public String atualizar(@PathVariable int id, @RequestBody Review review) {
        try {
            review.setID(id);
            boolean ok = dao.update(review);
            return ok ? "Review atualizada" : "Review não encontrada";
        } catch (Exception e) {
            return "Erro ao atualizar: " + e.getMessage();
        }
    }

    // 🔹 DELETAR
    @DeleteMapping("/{id}")
    public String deletar(@PathVariable int id) {
        try {
            boolean ok = dao.delete(id);
            return ok ? "Review deletada" : "Review não encontrada";
        } catch (Exception e) {
            return "Erro ao deletar: " + e.getMessage();
        }
    }
}