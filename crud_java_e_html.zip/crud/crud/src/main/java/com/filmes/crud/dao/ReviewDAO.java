package com.filmes.crud.dao;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.filmes.crud.index.HashExtensivel;
import com.filmes.crud.model.*;
import com.filmes.crud.util.*;

public class ReviewDAO {

    private final String FILE = "data/review.bin";
    private HashExtensivel indice;

    public ReviewDAO() throws IOException {
        initFile();
        indice = new HashExtensivel(2);
        reconstruirIndice();
    }

    private void initFile() throws IOException {
        RandomAccessFile raf = FileManeger.open(FILE);

        if (raf.length() == 0) {
            raf.writeInt(0);
        }

        raf.close();
    }

    private void reconstruirIndice() throws IOException {
        indice = new HashExtensivel(2);

        RandomAccessFile raf = FileManeger.open(FILE);
        raf.seek(4);

        while (raf.getFilePointer() < raf.length()) {
            long pos = raf.getFilePointer();

            int recordSize = raf.readInt();
            boolean active = raf.readBoolean();
            int id = raf.readInt();

            if (active) {
                indice.inserir(id, pos);
            }

            raf.seek(pos + 4L + recordSize);
        }

        raf.close();
    }

    // =========================
    // CREATE
    // =========================
    public int create(Review r) throws Exception {

        if (r.getRating() < 0 || r.getRating() > 10)
            throw new Exception("Nota deve ser entre 0 e 10");

        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(0);
        int lastID = raf.readInt();
        int newID = lastID + 1;

        raf.seek(0);
        raf.writeInt(newID);

        byte[] noteBytes = r.getNote().getBytes(StandardCharsets.UTF_8);

        int recordSize =
                1 + 4 +
                4 +
                4 +
                1 +
                2 + noteBytes.length;

        long pos = raf.length();
        raf.seek(pos);

        raf.writeInt(recordSize);

        raf.writeBoolean(true);
        raf.writeInt(newID);

        raf.writeInt(r.getUserID());
        raf.writeInt(r.getFilmID());
        raf.writeByte(r.getRating());

        raf.writeShort(noteBytes.length);
        raf.write(noteBytes);

        raf.close();

        indice.inserir(newID, pos);

        return newID;
    }

    // =========================
    // READ
    // =========================
    public Review read(int idBusca) throws IOException {

        Long pos = indice.buscar(idBusca);
        if (pos == null) return null;

        RandomAccessFile raf = FileManeger.open(FILE);
        Review review = readAtPosition(raf, pos, idBusca);
        raf.close();

        return review;
    }

    private Review readAtPosition(RandomAccessFile raf, long pos, int expectedId) throws IOException {

        raf.seek(pos);

        raf.readInt();
        boolean active = raf.readBoolean();
        int id = raf.readInt();

        if (!active || id != expectedId) return null;

        int userID = raf.readInt();
        int filmID = raf.readInt();
        byte rating = raf.readByte();

        short size = raf.readShort();
        byte[] noteBytes = new byte[size];
        raf.readFully(noteBytes);

        String note = new String(noteBytes, StandardCharsets.UTF_8);

        return new Review(id, userID, filmID, rating, note);
    }

    // =========================
    // READ ALL
    // =========================
    public List<Review> readAllToList() throws IOException {

        List<Review> lista = new ArrayList<>();

        RandomAccessFile raf = FileManeger.open(FILE);
        raf.seek(4);

        while (raf.getFilePointer() < raf.length()) {

            long pos = raf.getFilePointer();

            int recordSize = raf.readInt();
            boolean active = raf.readBoolean();
            int id = raf.readInt();

            if (active) {
                int userID = raf.readInt();
                int filmID = raf.readInt();
                byte rating = raf.readByte();

                short size = raf.readShort();
                byte[] noteBytes = new byte[size];
                raf.readFully(noteBytes);

                String note = new String(noteBytes, StandardCharsets.UTF_8);

                lista.add(new Review(id, userID, filmID, rating, note));
            }

            raf.seek(pos + 4L + recordSize);
        }

        raf.close();
        return lista;
    }

    // =========================
    // DELETE
    // =========================
    public boolean delete(int id) throws IOException {

        Long pos = indice.buscar(id);
        if (pos == null) return false;

        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(pos + 4);
        boolean active = raf.readBoolean();

        if (!active) {
            raf.close();
            return false;
        }

        raf.seek(pos + 4);
        raf.writeBoolean(false);

        raf.close();

        indice.remover(id);

        return true;
    }

    // =========================
    // UPDATE
    // =========================
    public boolean update(Review r) throws Exception {

        Long pos = indice.buscar(r.getID());
        if (pos == null) return false;

        if (r.getRating() < 0 || r.getRating() > 10)
            throw new Exception("Nota deve ser entre 0 e 10");

        RandomAccessFile raf = FileManeger.open(FILE);

        raf.seek(pos + 4);
        boolean active = raf.readBoolean();

        if (!active) {
            raf.close();
            return false;
        }

        raf.seek(pos + 4);
        raf.writeBoolean(false);

        raf.close();

        long novaPos = createWithIdRetornandoPosicao(r);
        indice.inserir(r.getID(), novaPos);

        return true;
    }

    private long createWithIdRetornandoPosicao(Review r) throws IOException {

        RandomAccessFile raf = FileManeger.open(FILE);

        byte[] noteBytes = r.getNote().getBytes(StandardCharsets.UTF_8);

        int recordSize =
                1 + 4 +
                4 +
                4 +
                1 +
                2 + noteBytes.length;

        long pos = raf.length();
        raf.seek(pos);

        raf.writeInt(recordSize);

        raf.writeBoolean(true);
        raf.writeInt(r.getID());

        raf.writeInt(r.getUserID());
        raf.writeInt(r.getFilmID());
        raf.writeByte(r.getRating());

        raf.writeShort(noteBytes.length);
        raf.write(noteBytes);

        raf.close();
        return pos;
    }
}