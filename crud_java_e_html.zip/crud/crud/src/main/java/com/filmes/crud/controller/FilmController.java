package com.filmes.crud.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.filmes.crud.model.Film;
import com.filmes.crud.service.FilmService;

@RestController
@RequestMapping("/filmes")
@CrossOrigin("*")
public class FilmController {

    private final FilmService filmService;

    public FilmController() throws Exception {
        filmService = new FilmService();
    }

    @GetMapping
    public List<Film> listar() throws Exception {
        return filmService.listFilmsToList();
    }

    @PostMapping
    public Object criar(@RequestBody Film film) {
        try {
            int id = filmService.createFilm(
                film.getTitle(),
                film.getDescription(),
                film.getReleaseDate(),
                film.getDirectors(),
                film.getRating()
            );

            Film filmeCriado = filmService.readFilm(id);
            return filmeCriado;

        } catch (Exception e) {
            e.printStackTrace();

            String mensagem = e.getMessage();
            if (mensagem == null || mensagem.isBlank()) {
                mensagem = "Erro interno ao cadastrar filme.";
            }

            return new ErrorResponse(mensagem);
        }
    }

    @GetMapping("/{id}")
    public Object buscar(@PathVariable int id) {
        try {
            Film film = filmService.readFilm(id);

            if (film == null) {
                return new ErrorResponse("Filme não encontrado.");
            }

            return film;

        } catch (Exception e) {
            e.printStackTrace();

            String mensagem = e.getMessage();
            if (mensagem == null || mensagem.isBlank()) {
                mensagem = "Erro interno ao buscar filme.";
            }

            return new ErrorResponse(mensagem);
        }
    }

    @PutMapping("/{id}")
    public Object atualizar(@PathVariable int id, @RequestBody Film film) {
        try {
            film.setID(id);

            boolean ok = filmService.updateFilm(film);

            if (ok) {
                Film filmeAtualizado = filmService.readFilm(id);
                return filmeAtualizado;
            }

            return new ErrorResponse("Filme não encontrado.");

        } catch (Exception e) {
            e.printStackTrace();

            String mensagem = e.getMessage();
            if (mensagem == null || mensagem.isBlank()) {
                mensagem = "Erro interno ao atualizar filme.";
            }

            return new ErrorResponse(mensagem);
        }
    }

    @DeleteMapping("/{id}")
    public Object excluir(@PathVariable int id) {
        try {
            boolean ok = filmService.deleteFilm(id);

            if (ok) {
                return new SuccessResponse("Filme excluído com sucesso.");
            }

            return new ErrorResponse("Filme não encontrado.");

        } catch (Exception e) {
            e.printStackTrace();

            String mensagem = e.getMessage();
            if (mensagem == null || mensagem.isBlank()) {
                mensagem = "Erro interno ao excluir filme.";
            }

            return new ErrorResponse(mensagem);
        }
    }

    static class ErrorResponse {
        public String message;

        public ErrorResponse(String message) {
            this.message = message;
        }
    }

    static class SuccessResponse {
        public String message;

        public SuccessResponse(String message) {
            this.message = message;
        }
    }
}