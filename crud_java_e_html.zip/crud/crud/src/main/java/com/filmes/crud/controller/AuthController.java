package com.filmes.crud.controller;

import com.filmes.crud.model.User;
import com.filmes.crud.dao.UserDAO;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@CrossOrigin("*")
public class AuthController {

    private UserDAO dao;

    public AuthController() throws Exception {
        dao = new UserDAO();
    }

    @PostMapping("/login")
    public Object login(@RequestBody User loginData) {
        try {
            User user = dao.readByEmail(loginData.getEmail());

            if (user != null && user.getPassword().equals(loginData.getPassword())) {
                return user;
            }

            return new ErrorResponse("Email ou senha incorretos.");
        } catch (Exception e) {
            return new ErrorResponse("Erro interno no servidor.");
        }
    }

    @PostMapping("/register")
    public Object register(@RequestBody User newUser) {
        try {
            if (newUser.getUsername() == null || newUser.getUsername().trim().isEmpty()) {
                return new ErrorResponse("Username é obrigatório.");
            }

            if (newUser.getEmail() == null || newUser.getEmail().trim().isEmpty()) {
                return new ErrorResponse("E-mail é obrigatório.");
            }

            if (newUser.getPassword() == null || newUser.getPassword().trim().isEmpty()) {
                return new ErrorResponse("Senha é obrigatória.");
            }

            User existente = dao.readByEmail(newUser.getEmail());
            if (existente != null) {
                return new ErrorResponse("Já existe um usuário com esse e-mail.");
            }

            int id = dao.create(newUser);
            newUser.setID(id);

            return newUser;
        } catch (Exception e) {
            return new ErrorResponse("Erro ao cadastrar usuário.");
        }
    }

    static class ErrorResponse {
        public String message;

        public ErrorResponse(String message) {
            this.message = message;
        }
    }
}