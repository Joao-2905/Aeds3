package CRUD.controller;

import CRUD.dao.ReviewDAO;
import CRUD.model.Review;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ReviewRestController {

    private ReviewDAO dao;

    public ReviewRestController() throws Exception {
        dao = new ReviewDAO();
    }

    // 🔥 LISTAR TODAS AS REVIEWS
    @GetMapping("/reviews")
    public List<Review> listar() throws Exception {
        return dao.readAllToList();
    }
}